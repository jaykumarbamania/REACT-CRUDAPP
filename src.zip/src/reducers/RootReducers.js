import { combineReducers } from "redux";
import { StudReducer } from "./StudReducer";


const rootReducer = combineReducers({StudReducer})

export default rootReducer;