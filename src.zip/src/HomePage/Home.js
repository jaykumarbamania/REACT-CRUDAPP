import React from 'react';

export default function Home() {
  return <div>
      <h1>This is Home Component</h1>
  </div>;
}
