export class Student {
    id;
    name;
    department;
    standard;
    constructor(id, name,department, standard) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.standard = standard;
    }
}
 