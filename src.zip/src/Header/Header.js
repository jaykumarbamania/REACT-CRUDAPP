import React from 'react';
import { NavLink } from 'react-router-dom';
import './Header.css';

export default function Header() {
  return (
    <div className="header">
        <div className='leftSide'>
        <NavLink to="/">Home</NavLink>
        <NavLink to="/students">Students</NavLink>
        <NavLink to="/add/student">Add</NavLink>
        </div>
        <div className='rightSide'>
        <NavLink to="/">Login</NavLink>
        <NavLink to="/">Register</NavLink>
        </div>
    </div>
  );
}
