import React from 'react';
import { useParams } from 'react-router-dom';

export default function EditStudent() {
    let {id} = useParams();

    let dispatch = useDispatch();
    
    useEffect(() => {
        dispatch(delStudent(parseInt(id)))
    },[]);
  return <div></div>;
}
