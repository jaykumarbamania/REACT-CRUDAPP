import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { NavLink } from 'react-router-dom';



function TableBody(){

    let studentArr = useSelector((reducer) => reducer.StudReducer)

    let [stuArr,setStudentArr] = useState([])

    useEffect(() => {
    setStudentArr(studentArr)
    },[stuArr])

    return (

        <tbody>
            {
                stuArr.map((student) =>{
                    return (
                        <tr key = {student.id}>
                            <td>{student.id}</td>
                            <td>{student.name}</td>
                            <td>{student.department}</td>
                            <td>{student.standard}</td>
                            <td>{student.standard}</td>
                            <td><NavLink to={`/edit/${student.id}`}>Delete</NavLink></td>
                            <td><NavLink to={`/delete/${student.id}`}>Delete</NavLink></td>
                        </tr>
                    )
                })
            }
            </tbody>
    )
}

let TableHeading  = () =>{
    return (
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Department</th>
                <th>Standard</th>
                <th>Delete</th>
            </tr>
        </thead>
    )
}


export default function ShowStudent() {
    let [displayForm, setDisplayForm] = useState(false);
    console.log(displayForm)
  return (
    <div>
        <table border={1}>
            <TableHeading />
            <TableBody />
            <button onClick={() => setDisplayForm(!displayForm)}>{displayForm?"Close form":"Add Student"}</button>
        </table>
       
    </div>
  );
}
